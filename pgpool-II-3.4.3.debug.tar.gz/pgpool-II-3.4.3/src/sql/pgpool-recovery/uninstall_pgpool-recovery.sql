DROP FUNCTION pgpool_switch_xlog(text);
DROP FUNCTION pgpool_remote_start(text, text);
DROP FUNCTION pgpool_recovery(text, text, text);
