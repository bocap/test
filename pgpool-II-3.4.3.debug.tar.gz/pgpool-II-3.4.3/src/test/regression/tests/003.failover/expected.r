 node_id | hostname | port  | status | lb_weight |  role  
---------+----------+-------+--------+-----------+--------
 0       | /tmp     | 11002 | 2      | 0.500000  | master
 1       | /tmp     | 11003 | 3      | 0.500000  | slave
(2 rows)

