SET var TO val
SET var TO 'val'
SET var TO DEFAULT
SET var = DEFAULT
SET TIME ZONE val
SET TIME ZONE 'val'
SET TIME ZONE local
SET TIME ZONE default
SET local TIME ZONE default
SET session TIME ZONE default
SET var FROM CURRENT
SET XML OPTION DOCUMENT
SET XML OPTION CONTENT
show 'x';
show x;
show all;
reset x;
reset all;
reset time zone;
reset transaction isolation level
reset session authorization
reset 'x';
