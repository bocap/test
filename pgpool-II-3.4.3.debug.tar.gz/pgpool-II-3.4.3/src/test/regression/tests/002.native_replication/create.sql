CREATE TABLE sequencetester
(
  id serial NOT NULL,
  recordno integer,
  CONSTRAINT sq_pk PRIMARY KEY (id )
)
