#define PGPOOLVERSION "ekieboshi"
