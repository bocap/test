BEGIN;
select 2;
END;
