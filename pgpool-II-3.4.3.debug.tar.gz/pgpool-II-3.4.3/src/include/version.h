#define PGPOOLVERSION "tataraboshi"
