 node_id | hostname | port  | status | lb_weight |  role  | select_cnt 
---------+----------+-------+--------+-----------+--------+------------
 0       | /tmp     | 11002 | 2      | 0.500000  | master | 0
 1       | /tmp     | 11003 | 3      | 0.500000  | slave  | 0
(2 rows)

